% function display(c)
%
% DESCRIPTION:
% ============ 
%
% INPUTS:
% =======
%
% OUTPUTS:
% ========
% 
% Copyright (c) 2011 IRCAM/McGill, All Rights Reserved.
% Permission is only granted to use for research purposes
%

function display(c)

disp(c.f_LenX);

return;