% function i_Len = FGetLen(c)
%
% DESCRIPTION:
% ============
%
% INPUTS:
% =======
%
% OUTPUTS:
% ========
%
% Copyright (c) 2011 IRCAM/ McGill, All Rights Reserved.
% Permission is only granted to use for research purposes
%

function i_Len = FGetLen(c)

i_Len = c.i_Len;

return;