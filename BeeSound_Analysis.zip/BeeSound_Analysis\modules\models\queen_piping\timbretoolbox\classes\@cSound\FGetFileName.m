% function wFN = FGetFileName(c)
%
% DESCRIPTION:
% ============
%
% INPUTS:
% =======
%
% OUTPUTS:
% ========
%
% Copyright (c) 2011 IRCAM/ McGill, All Rights Reserved.
% Permission is only granted to use for research purposes
%

function wFN = FGetFileName(c)

wFN = c.w_FileName;

return;
