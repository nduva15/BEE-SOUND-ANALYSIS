species_id = [
    "Apis Mellifera",
    "Bombus Dahlbomii",
    "Bombus Ruderatus",
    "Bombus Terrestris",
    "Cadeguala Occidentalis",
    "Centris Cineraria",
    "Colletes Cyanescens",
    "Colletes Nigritulus",
    "Corynura Chloris",
    "Corynura Sp",
    "Diphaglossa Gayi",
    "Lasioglossum Sp",
    "Manuelia Postica",
    "Ruizantheda Mutabilis",
    "Ruizantheda Proxima"
]