//possible beehive states
using namespace std;

 #ifndef _STATES_
 #define _STATES_

const string states[]={"test","active","dormant","pre-swarm","swarm","sick_v","sick_w","sick_n","theft","collapsed", "missing_queen", "queen_hatching"};

 #endif