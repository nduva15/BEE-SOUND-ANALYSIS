% function r = FGetSampRate(c)
%
% DESCRIPTION:
% ============ 
%
% INPUTS:
% =======
%
% OUTPUTS:
% ========
% 
% Copyright (c) 2011 IRCAM/McGill, All Rights Reserved.
% Permission is only granted to use for research purposes
%

function r = FGetSampRate(c)

r = [c.f_SampRateX, c.f_SampRateY];

return;