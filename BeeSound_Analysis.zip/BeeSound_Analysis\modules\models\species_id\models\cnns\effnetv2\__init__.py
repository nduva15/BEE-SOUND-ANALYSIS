import sys

sys.path.append("models/cnns/effnetv2")