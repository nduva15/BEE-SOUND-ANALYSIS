%function Fs = FGetSampRate(c)
%
% DESCRIPTION:
% ============
%
% INPUTS:
% =======
%
% OUTPUTS:
% ========
%
% Copyright (c) 2011 IRCAM/ McGill, All Rights Reserved.
% Permission is only granted to use for research purposes
%

function Fs = FGetSampRate(c)

Fs = c.f_Fs;

return;