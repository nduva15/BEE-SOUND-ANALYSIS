## R CMD check results

0 errors | 0 warnings | 0 note

## Changes in version 0.2.10

* Drop C++11 support to comply with CRAN requirements

## Test environments

* local R installation, R 4.5.1
* ubuntu-latest (on GitHub Actions), R-release
* windows-latest (on GitHub Actions), R-release  
* macOS-latest (on GitHub Actions), R-release
* R-hub builder

## Downstream dependencies

There are currently no downstream dependencies for this package.
