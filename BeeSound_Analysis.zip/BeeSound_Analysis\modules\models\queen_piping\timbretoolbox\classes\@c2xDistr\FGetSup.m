% function [y, x] = FGetSup(c)
%
% DESCRIPTION:
% ============ 
%
% INPUTS:
% =======
%
% OUTPUTS:
% ========
% 
% Copyright (c) 2011 IRCAM/McGill, All Rights Reserved.
% Permission is only granted to use for research purposes
%

function [y, x] = FGetSup(c)

x = c.f_SupX_v;
y = c.f_SupY_v;

return;