//Window Length in s
float windowLength=2;

//Sampling Rate in Hz
float samplingRate=6300;

